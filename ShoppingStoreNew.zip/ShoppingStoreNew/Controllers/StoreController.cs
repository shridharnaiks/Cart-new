﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Data;
using System.Data.SqlClient;

using Entities;
namespace ShoppingStoreNew.Controllers
{
    public class StoreController : Controller
    {
      
        ShoppingStoreEntities storeDB = new ShoppingStoreEntities();
        // GET: Store
        public ActionResult Index()
        {

            var categories = storeDB.Category.ToList();          
            return View(categories);
        }
        public ActionResult Browse(string category)
        {
            var categoryModel = storeDB.Category.Include("Items")
                .Single(c => c.Name == Category);
            return View(categoryModel);
        }
        public ActionResult Details(int id)
        {
            var Item = new Item { Title = "Item" + id };
            return View(Item);
        }
    }
}